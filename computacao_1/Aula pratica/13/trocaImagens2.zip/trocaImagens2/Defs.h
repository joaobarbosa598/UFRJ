#ifndef DEFS_H
#define DEFS_H

//Definindo as dimensoes da tela
#define SCREEN_WIDTH 600
#define SCREEN_HEIGHT 600
#define false 0
#define true !false

#endif
