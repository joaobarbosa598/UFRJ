#ifndef GLOBAIS_H
#define GLOBAIS_H

/* Globais */
extern SDL_Window* gWindow;
extern SDL_Surface* gScreenSurface;
extern SDL_Surface* gImagem1;   // 300x225
extern SDL_Surface* gImagem2;   // 300x225
extern Mix_Chunk* som;


#endif
